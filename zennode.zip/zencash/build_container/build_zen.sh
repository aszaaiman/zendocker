#!/bin/bash
docker run -v ~/zencash/zen:/app zencash-build
