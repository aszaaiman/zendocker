#!/bin/bash
rm -rf ./zen
git clone https://github.com/zencashio/zen
