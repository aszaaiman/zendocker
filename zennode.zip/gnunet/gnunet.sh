#!/bin/bash
gnunet-arm -s -c gnunet.conf
sleep infinity
