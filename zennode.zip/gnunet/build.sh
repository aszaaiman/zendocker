#!/bin/bash
docker build -t gnunet-run .
